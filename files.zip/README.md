# FreeClipper

Free, open-source auto-clipper. Give it a long video (**up to 8 hours**) and it
produces short clips with **auto-generated, word-highlighted captions** exported
in **1080p**. Runs locally: no API keys, no watermark, no subscription.

## How it works
1. Transcribes with [faster-whisper](https://github.com/SYSTRAN/faster-whisper) (word-level timestamps)
2. Scores sentence-aligned windows (speech density, hook words, questions) and picks the top non-overlapping clips
3. Cuts with ffmpeg and burns in captions, 1920x1080 (or 1080x1920 with `--vertical`)

## Install
```bash
# 1. install ffmpeg (https://ffmpeg.org/download.html)
#    macOS: brew install ffmpeg | Ubuntu: sudo apt install ffmpeg
# 2.
pip install -r requirements.txt
```

## Use
```bash
python clipper.py my_podcast.mp4                    # 5 clips, 1920x1080
python clipper.py "https://youtu.be/XXXX" -n 8      # from a URL
python clipper.py talk.mp4 --vertical               # 1080x1920 for Shorts/Reels/TikTok
python clipper.py talk.mp4 --min 30 --max 90 --model medium --language en
python clipper.py talk.mp4 --no-captions
```

Output goes to `clips/`: `clip_01.mp4 ...`, plus `transcript.json` (cached, so
re-runs are fast) and `clips.json` (timestamps + scores).

## Notes
- Hard limit: inputs longer than 8 hours are rejected (`MAX_SECONDS` in `clipper.py`).
- Transcription is the slow step. A GPU speeds it up a lot; on CPU use `--model base` or `small`.
- Clip selection is a simple heuristic, not a virality predictor. Edit `HOOK_WORDS` / `score()` to tune it.
- Only download/clip content you have the rights to use.

## License
MIT
