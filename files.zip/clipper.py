#!/usr/bin/env python3
"""
FreeClipper - turn a long video (up to 8 hours) into short, captioned 1080p clips.

100% free and local: faster-whisper (transcription) + ffmpeg (cutting/captions).
No API keys, no watermark, no cloud.
"""
import argparse
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

MAX_SECONDS = 8 * 3600  # hard input limit: 8 hours

HOOK_WORDS = {
    "secret", "never", "always", "mistake", "truth", "actually", "crazy",
    "insane", "biggest", "worst", "best", "why", "how", "stop", "warning",
    "nobody", "everyone", "story", "learned", "problem", "money", "free",
    "important", "wrong", "believe", "amazing", "shocking",
}


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def run(cmd, **kw):
    subprocess.run(cmd, check=True, **kw)


def probe_duration(path: Path) -> float:
    out = subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=nw=1:nk=1", str(path),
    ])
    return float(out.strip())


def download(url: str, outdir: Path) -> Path:
    """Download a URL with yt-dlp (refuses videos over the 8h limit)."""
    run([
        "yt-dlp",
        "--match-filter", f"duration<={MAX_SECONDS}",
        "-f", "bv*[height<=1080]+ba/b[height<=1080]/b",
        "--merge-output-format", "mp4",
        "-o", str(outdir / "source.%(ext)s"),
        url,
    ])
    files = list(outdir.glob("source.*"))
    if not files:
        sys.exit("Download failed or video is longer than 8 hours.")
    return files[0]


# --------------------------------------------------------------------------
# transcription
# --------------------------------------------------------------------------
def transcribe(video: Path, model_size: str, language, cache: Path):
    if cache.exists():
        print(f"Using cached transcript: {cache}")
        return json.loads(cache.read_text())

    from faster_whisper import WhisperModel

    print(f"Transcribing with Whisper '{model_size}' (this is the slow part)...")
    model = WhisperModel(model_size, device="auto", compute_type="auto")
    segments, _ = model.transcribe(
        str(video), word_timestamps=True, vad_filter=True, language=language
    )
    result = []
    for s in segments:
        result.append({
            "start": s.start,
            "end": s.end,
            "text": s.text.strip(),
            "words": [
                {"w": w.word.strip(), "start": w.start, "end": w.end}
                for w in (s.words or [])
            ],
        })
        if len(result) % 50 == 0:
            print(f"  ...{s.end / 60:.0f} min transcribed")
    cache.write_text(json.dumps(result))
    return result


# --------------------------------------------------------------------------
# clip selection (simple heuristic, no paid AI)
# --------------------------------------------------------------------------
def score(segs, dur):
    text = " ".join(s["text"] for s in segs)
    words = re.findall(r"[\w']+", text.lower())
    if not words:
        return 0.0
    wps = len(words) / dur
    hooks = sum(1 for w in words if w in HOOK_WORDS)
    questions = text.count("?")
    excl = text.count("!")
    first = re.findall(r"[\w']+", segs[0]["text"].lower())
    opener = 2.0 if any(w in HOOK_WORDS for w in first) or "?" in segs[0]["text"] else 0.0
    return min(wps, 4.0) * 2 + min(hooks, 8) * 1.5 + min(questions, 4) + min(excl, 4) + opener


def find_clips(segs, min_len, max_len, count):
    cands = []
    for i in range(len(segs)):
        start = segs[i]["start"]
        for j in range(i, len(segs)):
            dur = segs[j]["end"] - start
            if dur > max_len:
                break
            if dur >= min_len and segs[j]["text"][-1:] in ".?!":
                cands.append((score(segs[i:j + 1], dur), start, segs[j]["end"]))
                break

    cands.sort(reverse=True)
    chosen = []
    for sc, s, e in cands:
        if all(e <= cs or s >= ce for _, cs, ce in chosen):  # no overlap
            chosen.append((sc, s, e))
        if len(chosen) >= count:
            break
    return sorted(chosen, key=lambda c: c[1])


# --------------------------------------------------------------------------
# captions (ASS, word-by-word highlight)
# --------------------------------------------------------------------------
def ass_time(t: float) -> str:
    cs = max(0, round(t * 100))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def build_ass(words, clip_start, clip_end, width, height, vertical, path: Path):
    font_size = int(height * (0.045 if vertical else 0.06))
    margin_v = int(height * (0.22 if vertical else 0.07))
    header = (
        "[Script Info]\nScriptType: v4.00+\n"
        f"PlayResX: {width}\nPlayResY: {height}\nWrapStyle: 2\n\n"
        "[V4+ Styles]\n"
        "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,"
        "BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,"
        "BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\n"
        f"Style: Default,Arial,{font_size},&H0000E5FF,&H00FFFFFF,&H00000000,&H80000000,"
        f"1,0,0,0,100,100,0,0,1,{max(3, font_size // 12)},1,2,"
        f"{int(width * 0.08)},{int(width * 0.08)},{margin_v},1\n\n"
        "[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n"
    )

    ws = [w for w in words if w["start"] >= clip_start - 0.05 and w["end"] <= clip_end + 0.5]

    # group into short lines (max 4 words, break on pauses)
    groups, cur = [], []
    for w in ws:
        if cur and (len(cur) >= 4 or w["start"] - cur[-1]["end"] > 0.8):
            groups.append(cur)
            cur = []
        cur.append(w)
    if cur:
        groups.append(cur)

    lines = []
    for gi, g in enumerate(groups):
        g_start = g[0]["start"] - clip_start
        g_end = g[-1]["end"] - clip_start
        if gi + 1 < len(groups):  # hold until next line starts (max 0.4s)
            g_end = min(groups[gi + 1][0]["start"] - clip_start, g_end + 0.4)
        parts = []
        for k, w in enumerate(g):
            nxt = g[k + 1]["start"] if k + 1 < len(g) else w["end"]
            cs = max(1, round((nxt - w["start"]) * 100))
            word = w["w"].upper().replace("{", "(").replace("}", ")")
            parts.append(f"{{\\kf{cs}}}{word}")
        lines.append(
            f"Dialogue: 0,{ass_time(g_start)},{ass_time(g_end)},Default,,0,0,0,,"
            + " ".join(parts)
        )
    path.write_text(header + "\n".join(lines) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------
# render 1080p
# --------------------------------------------------------------------------
def render(video: Path, outdir: Path, idx: int, start, end, words, vertical, captions):
    width, height = (1080, 1920) if vertical else (1920, 1080)
    start = max(0.0, start - 0.2)
    end = end + 0.4
    name = f"clip_{idx:02d}"
    ass_name = f"{name}.ass"

    if vertical:
        vf = f"crop=trunc(ih*9/32)*2:ih,scale={width}:{height}"
    else:
        vf = (f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
              f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2")

    if captions:
        build_ass(words, start, end, width, height, vertical, outdir / ass_name)
        vf += f",ass={ass_name}"

    run([
        "ffmpeg", "-y", "-loglevel", "error", "-ss", f"{start:.2f}",
        "-i", str(video.resolve()), "-t", f"{end - start:.2f}",
        "-vf", vf,
        "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
        f"{name}.mp4",
    ], cwd=outdir)  # cwd=outdir keeps the ass= path simple on every OS
    return f"{name}.mp4"


# --------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description="Free auto-clipper with captions (1080p, max 8h input).")
    p.add_argument("input", help="video file path or URL (YouTube etc.)")
    p.add_argument("-o", "--out", default="clips", help="output folder")
    p.add_argument("-n", "--clips", type=int, default=5, help="number of clips")
    p.add_argument("--min", type=float, default=20, help="min clip length (s)")
    p.add_argument("--max", type=float, default=60, help="max clip length (s)")
    p.add_argument("--model", default="small", help="whisper model: tiny/base/small/medium/large-v3")
    p.add_argument("--language", default=None, help="e.g. en (default: auto-detect)")
    p.add_argument("--vertical", action="store_true", help="1080x1920 (9:16) instead of 1920x1080")
    p.add_argument("--no-captions", action="store_true", help="skip burned-in captions")
    a = p.parse_args()

    outdir = Path(a.out)
    outdir.mkdir(parents=True, exist_ok=True)

    if re.match(r"https?://", a.input):
        tmp = Path(tempfile.mkdtemp(prefix="clipper_"))
        video = download(a.input, tmp)
    else:
        video = Path(a.input)
        if not video.exists():
            sys.exit(f"File not found: {video}")

    duration = probe_duration(video)
    if duration > MAX_SECONDS:
        sys.exit(f"Video is {duration / 3600:.1f}h long - the limit is 8 hours.")
    print(f"Video length: {duration / 60:.1f} min")

    segs = transcribe(video, a.model, a.language, outdir / "transcript.json")
    if not segs:
        sys.exit("No speech detected.")

    picks = find_clips(segs, a.min, a.max, a.clips)
    if not picks:
        sys.exit("Couldn't find suitable clips - try a wider --min/--max range.")

    all_words = [w for s in segs for w in s["words"]]
    meta = []
    for i, (sc, s, e) in enumerate(picks, 1):
        print(f"Rendering clip {i}/{len(picks)}  [{s:.0f}s - {e:.0f}s]  score {sc:.1f}")
        fn = render(video, outdir, i, s, e, all_words, a.vertical, not a.no_captions)
        meta.append({"file": fn, "start": round(s, 2), "end": round(e, 2), "score": round(sc, 2)})

    (outdir / "clips.json").write_text(json.dumps(meta, indent=2))
    print(f"\nDone. {len(meta)} clips saved in: {outdir.resolve()}")


if __name__ == "__main__":
    main()
